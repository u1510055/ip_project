<!doctype html>
<html>
	<head>
		<meta charset = "utf-8"/>
		<meta name = "viewport" content = "width = device - width"/>
		<link rel = "stylesheet" type = "text/css" href = "../css/page_style.css"/>
		<script type="text/javascript" src="../jquery/jquery-3.0.0.min.js"></script>
		<script type="text/javascript" src="../js/jq_load_script.js"></script>
		<script type="text/javascript" src="../js/product_js_script.js"></script>
	</head>
	<body>
		<div id = "load"></div>
			<nav class = "fixed">
				<div class = "nav_bar">
					<ul>
						<a href = "../index.php"><li>HOME</li></a>
						<a href = "#"><li>PRODUCTS</li></a>
						<a href = "#"><li>ABOUT</li></a>
						<a href = "#"><li>CONTACT</li></a>
					</ul>
				</div>
			</nav>
			<div id = "baner"></div>
			<div class = "container">
				<div class = "wrapper">
					<div class = "colume">
						<a href = "adidas.php">
							<div id = "adidas_cover">
								<div id = "adidas_round">
									<img id = "adidas_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">ADIDAS</p>
					</div>

					<div class = "colume">
						<a href = "BOSS.php">
							<div id = "boss_cover">
								<div id = "boss_round">
									<img id = "boss_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">BOSS</p>
					</div>
				
					<div class = "colume">
						<a href = "D&G.php">
							<div id = "dg_cover">
								<div id = "dg_round">
									<img id = "dg_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">D&G</p>
					</div>
				
					<div class = "colume">
						<a href = "NIKE.php">
							<div id = "nike_cover">
								<div id = "nike_round">
									<img id = "nike_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">NIKE</p>
					</div>

					<div class = "colume">
						<a href = "PUMA.php">
							<div id = "puma_cover">
								<div id = "puma_round">
									<img id = "puma_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">PUMA</p>
					</div>
					<div class = "product_panel">
						<div class = "product_image_box">
						<div class = "small_box">
							<div id = "product_image_1"></div>
							<div id = "product_image_2"></div>
							<div id = "product_image_3"></div>
							<div id = "product_image_4"></div>
						</div>
						<div id = "product_image"></div>
						</div>
						<div class = "product_info_box">
							<p id = "product_title">Infomartion</p>
							<p id = "product_info_txt">
								This is all the information about the product you have chousen. All what you want to know about it's quality.
								This is all the information about the product you have chousen. All what you want to know about it's quality.
							</p>
							<div id = "size_box">
								<p id = "size">XL</p>
							</div>
							<div id = "size_box">
								<p id = "size">XX</p>
							</div>
							<div id = "size_box">
								<p id = "size">LL</p>
							</div><br/>
							<a href="login/login.php"><button id = "btn">Buy product</button></a>
							<button id = "btn">Save Info.</button><br/>
							<button id = "btn">Pictures</button>
							<button id = "btn">Like</button>
						</div>
					</div>
				</div>
			</div>
			<div class = "footer">
				<div class = "footer_wrapper">
					<div class = "footer_colume">
						<p id = "footer_caption">SEARCH</p>
						<p id = "footer_discription">
							Look for something importent so earjent use this service. This saves you your time your money and of course traffic.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">CONTENT</p>
						<p id = "footer_discription">
							Lets introduse you our products:<br/>
							- all tipe of media<br/>
							- online shoping<br/>
							- net study<br/>
							We work to make yout life easy and comfortable.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">DOWNLOADS</p>
						<p id = "footer_discription">
							In out website you can find for free:<br/>
							- movies<br/>
							- music<br/>
							- softwares<br/>
							- games<br/>	
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">TEAM</p>
						<p id = "footer_discription">
							Heare you can find all information about our team, creators of this site, and some editional tecnical information about site.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">CONTACT</p>
						<p id = "footer_discription">
							Our contact information whether if some problens or question ocure releted to this site.Feel free to contact us. 
						</p>
					</div>
					<p id = "web_info_txt">&copy; 2017 tamplate by Nodirbek, Baxtiyor and Jahongir</p>
				</div>
			</div>
	</body>
</html>