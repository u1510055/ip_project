<!doctype html>
<html>
	<head>
		<meta charset = "utf-8"/>
		<meta name = "viewport" content = "width = device - width"/>
		<link rel = "stylesheet" type = "text/css" href = "../css/page_style.css"/>
		<script type="text/javascript" src="../jquery/jquery-3.0.0.min.js"></script>
		<script type="text/javascript" src="../js/jq_load_script.js"></script>
		<script type="text/javascript" src="../js/j_script_BOSS_woman.js"></script>
	</head>
	<body>
		<div id = "load"></div>
			<div class = "menu">
				<ul>
					<li id = "logo_item"><img id = "BOSS_logo_icon"></li>
					<li id = "cap_item"><img id = "cap_icon"></li>
					<li id = "t_shirt_item"><img id = "t_shirt_icon"></li>
					<li id = "shorts_item"><img id = "shorts_icon"></li>
					<li id = "trousers_item"><img id = "trousers_icon"></li>
					<li id = "trainers_item"><img id = "trainers_icon"></li>
				</ul>
			</div>
			<nav class = "fixed">
				<div class = "nav_bar">
					<ul>
						<a href = "../index.php"><li>HOME</li></a>
						<a href = "#"><li>PRODUCTS</li></a>
						<a href = "#"><li>ABOUT</li></a>
						<a href = "#"><li>CONTACT</li></a>
					</ul>
				</div>
			</nav>
			<div id = "baner"></div>
			<div class = "container">
				<div class = "wrapper">
					<div class = "colume">
						<a href = "adidas.php">
							<div id = "adidas_cover">
								<div id = "adidas_round">
									<img id = "adidas_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">ADIDAS</p>
					</div>

					<div class = "colume">
						<a href = "BOSS.php">
							<div id = "boss_cover">
								<div id = "boss_round">
									<img id = "boss_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">BOSS</p>
					</div>
				
					<div class = "colume">
						<a href = "D&G.php">
							<div id = "dg_cover">
								<div id = "dg_round">
									<img id = "dg_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">D&G</p>
					</div>
				
					<div class = "colume">
						<a href = "NIKE.php">
							<div id = "nike_cover">
								<div id = "nike_round">
									<img id = "nike_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">NIKE</p>
					</div>

					<div class = "colume">
						<a href = "PUMA.php">
							<div id = "puma_cover">
								<div id = "puma_round">
									<img id = "puma_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">PUMA</p>
					</div>
					<div class = "image_colume">
						<a id = "link_1" href = "#">
							<div id = "image_box">
								<p id = "image_caption_1">350.25$</p>
								<p id = "discription_caption_1">men-clothis</p>
								<img id = "example_image_1"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_2" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_2">350.25$</p>
								<p id = "discription_caption_2">men-clothis</p>
								<img id = "example_image_2"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_3" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_3">350.25$</p>
								<p id = "discription_caption_3">men-clothis</p>
								<img id = "example_image_3"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_4" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_4">350.25$</p>
								<p id = "discription_caption_4">men-clothis</p>
								<img id = "example_image_4"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_5" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_5">350.25$</p>
								<p id = "discription_caption_5">men-clothis</p>
								<img id = "example_image_5"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_6" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_6">350.25$</p>
								<p id = "discription_caption_6">men-clothis</p>
								<img id = "example_image_6"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_7" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_7">350.25$</p>
								<p id = "discription_caption_7">men-clothis</p>
								<img id = "example_image_7"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_8" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_8">350.25$</p>
								<p id = "discription_caption_8">men-clothis</p>
								<img id = "example_image_8"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a id = "link_9" href = "product.php">
							<div id = "image_box">
								<p id = "image_caption_9">350.25$</p>
								<p id = "discription_caption_9">men-clothis</p>
								<img id = "example_image_9"/>
							</div>
						</a>
					</div>
				</div>
			</div>
			<div class = "footer">
				<div class = "footer_wrapper">
					<div class = "footer_colume">
						<p id = "footer_caption">SEARCH</p>
						<p id = "footer_discription">
							Look for something importent so earjent use this service. This saves you your time your money and of course traffic.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">CONTENT</p>
						<p id = "footer_discription">
							Lets introduse you our products:<br/>
							- all tipe of media<br/>
							- online shoping<br/>
							- net study<br/>
							We work to make yout life easy and comfortable.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">DOWNLOADS</p>
						<p id = "footer_discription">
							In out website you can find for free:<br/>
							- movies<br/>
							- music<br/>
							- softwares<br/>
							- games<br/>	
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">TEAM</p>
						<p id = "footer_discription">
							Heare you can find all information about our team, creators of this site, and some editional tecnical information about site.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">CONTACT</p>
						<p id = "footer_discription">
							Our contact information whether if some problens or question ocure releted to this site.Feel free to contact us. 
						</p>
					</div>
					<p id = "web_info_txt">&copy; 2017 tamplate by Islomjon</p>
				</div>
			</div>
	</body>
</html>