<!doctype html>
<html>
	<head>
		<meta charset = "utf-8"/>
		<meta name = "viewport" content = "width = device - width"/>
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css"/>
		<script type="text/javascript" src="../jquery/jquery-3.0.0.min.js"></script>
		<script type="text/javascript" src="../js/jq_load_script.js"></script>
	</head>
	<body>
		<div id = "load"></div>
		<div id = "content">
			<div id = "baner"></div>
			<section id = "screan_1">
				<div class = "header">
					<p id = "title">SPORT ONLINE MARKET</p>
					<p id = "sub_title">It is easy to buy sport clothes with us
					Make life better with us</p>
				</div>
				<nav>
					<div class = "wrapper">
						<ul>
							<a href = "../index.php"><li>HOME</li></a>
							<a href = "#"><li>PRODUCTS</li></a>
							<a href = "#"><li>ABOUT</li></a>
							<a href = "#"><li>CONTACT</li></a>
						</ul>
					</div>
				</nav>
			</section>
			<section id = "screan_2">
				<div class = "wrapper">
					<div class = "colume">
						<a href = "adidas.php">
							<div id = "adidas_cover">
								<div id = "adidas_round">
									<img id = "adidas_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">ADIDAS</p>
					</div>

					<div class = "colume">
						<a href = "BOSS.php">
							<div id = "boss_cover">
								<div id = "boss_round">
									<img id = "boss_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">BOSS</p>
					</div>
				
					<div class = "colume">
						<a href = "D&G.php">
							<div id = "dg_cover">
								<div id = "dg_round">
									<img id = "dg_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">D&G</p>
					</div>
				
					<div class = "colume">
						<a href = "NIKE.php">
							<div id = "nike_cover">
								<div id = "nike_round">
									<img id = "nike_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">NIKE</p>
					</div>

					<div class = "colume">
						<a href = "PUMA.php">
							<div id = "puma_cover">
								<div id = "puma_round">
									<img id = "puma_picture"/>
								</div>
							</div>
						</a>
						<p id = "caption">PUMA</p>
					</div>
					<div class = "brand"><img id = "BOSS_brand"/></div>
					<div class = "image_colume">
						<a href = "BOSS_men.php">
							<div id = "image_box">
								<img id = "type_icon_1"/>
								<p id = "image_caption">men</p>
								<img id = "example_image_1"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a href = "BOSS_woman.php">
							<div id = "image_box">
								<img id = "type_icon_2"/>
								<p id = "image_caption">woman</p>
								<img id = "example_image_2"/>
							</div>
						</a>
					</div>
					<div class = "image_colume">
						<a href = "BOSS_children.php">
							<div id = "image_box">
								<img id = "type_icon_3"/>
								<p id = "image_caption">children</p>
								<img id = "example_image_3"/>
							</div>
						</a>
					</div>
				</div>
			<section id = "screan_3">
				<div class = "footer_wrapper">
					<div class = "footer_colume">
						<p id = "footer_caption">SEARCH</p>
						<p id = "footer_discription">
							Look for something importent so earjent use this service. it is 
							here to search easy. You have chance to find clothes with pressing
							button
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">CONTENT</p>
						<p id = "footer_discription">
							Lets introduse you our products:<br/>
							- all tipe of sport clothes<br/>
							- online shoping<br/>
							- net pay and delevery service<br/>
							We work to make yout life easy and comfortable.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">BRENDS</p>
						<p id = "footer_discription">
							Here given our products brends<br/>
							- adidas<br/>
							- puma<br/>
							- D&G<br/>
							- boss<br/>
							 -nike<br/>	
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">SALES</p>
						<p id = "footer_discription">
							Heare you can find all information about our sales, Nowadays we have 
							more 1000 clients and they are satisfied with us.
						</p>
					</div>
					<div class = "footer_colume">
						<p id = "footer_caption">CONTACT</p>
						<p id = "footer_discription">
							Our contact information whether if some problens or question ocure releted to this site.Feel free to contact us. 
						</p>
					</div>
					<p id = "web_info_txt">&copy; 2017 tamplate by Nodirbek Baxtiyor and Jahongir</p>
				</div>
			</section>
		</div>
	</body>
</html>