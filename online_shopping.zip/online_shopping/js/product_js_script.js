var counter = 0;

var images = new Array("url(../img/l10.jpg)", "url(../img/l20.jpg)",
					"url(../img/l30.jpg)", "url(../img/l40.jpg)");
					
var small = new Array("url(../img/l11.jpg)", "url(../img/l21.jpg)",
					"url(../img/l31.jpg)", "url(../img/l41.jpg)");
					
window.onload = function(){
	var product_image = document.getElementById("product_image");
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
	
	var product_image_1 = document.getElementById("product_image_1");
	product_image_1.style.background = small[0];
	product_image_1.style.backgroundPosition = "center center";
	product_image_1.style.backgroundRepeat = "no-repeat";
	
	product_image_1.onmouseover = product_1_mouse_over;
	product_image_1.onmouseout = product_1_cmouse_out;
	product_image_1.onclick = product_1_click;
	
	var product_image_2 = document.getElementById("product_image_2");
	product_image_2.style.background = small[1];
	product_image_2.style.backgroundPosition = "center center";
	product_image_2.style.backgroundRepeat = "no-repeat";
	
	product_image_2.onmouseover = product_2_mouse_over;
	product_image_2.onmouseout = product_2_cmouse_out;
	product_image_2.onclick = product_2_click;
	
	var product_image_3 = document.getElementById("product_image_3");
	product_image_3.style.background = small[2];
	product_image_3.style.backgroundPosition = "center center";
	product_image_3.style.backgroundRepeat = "no-repeat";
	
	product_image_3.onmouseover = product_3_mouse_over;
	product_image_3.onmouseout = product_3_cmouse_out;
	product_image_3.onclick = product_3_click;
	
	var product_image_4 = document.getElementById("product_image_4");
	product_image_4.style.background = small[3];
	product_image_4.style.backgroundPosition = "center center";
	product_image_4.style.backgroundRepeat = "no-repeat";
	
	product_image_4.onmouseover = product_4_mouse_over;
	product_image_4.onmouseout = product_4_cmouse_out;
	product_image_4.onclick = product_4_click;
};

//samll 1
function product_1_click(){
	counter = 0;
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_1_mouse_over(){
	product_image.style.background = images[0];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_1_cmouse_out(){
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}

//samll 2
function product_2_click(){
	counter = 1;
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_2_mouse_over(){
	product_image.style.background = images[1];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_2_cmouse_out(){
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}

//samll 3
function product_3_click(){
	counter = 2;
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_3_mouse_over(){
	product_image.style.background = images[2];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_3_cmouse_out(){
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
//samll 4
function product_4_click(){
	counter = 3;
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_4_mouse_over(){
	product_image.style.background = images[3];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}
function product_4_cmouse_out(){
	product_image.style.background = images[counter];
	product_image.style.backgroundPosition = "center center";
	product_image.style.backgroundRepeat = "no-repeat";
}