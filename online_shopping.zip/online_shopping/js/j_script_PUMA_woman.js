var cap_index = 0;
var t_shirt_index = 0;
var shorts_index = 0;
var trousers_index = 0;
var trainers_index = 0;

window.onload = function(){
	var cap_item = document.getElementById("cap_item");
	cap_item.onclick = cap_click;
	cap_item.onmouseover = cap_mouse_over;
	cap_item.onmouseout = cap_mouse_out;
	
	var t_shirt_item = document.getElementById("t_shirt_item");
	t_shirt_item.onclick = t_shirt_click;
	t_shirt_item.onmouseover = t_shirt_mouse_over;
	t_shirt_item.onmouseout = t_shirt_mouse_out;
	
	var shorts_item = document.getElementById("shorts_item");
	shorts_item.onclick = shorts_click;
	shorts_item.onmouseover = shorts_mouse_over;
	shorts_item.onmouseout = shorts_mouse_out;
	
	var trousers_item = document.getElementById("trousers_item");
	trousers_item.onclick = trousers_click;
	trousers_item.onmouseover = trousers_mouse_over;
	trousers_item.onmouseout = trousers_mouse_out;
	
	var trainers_item = document.getElementById("trainers_item");
	trainers_item.onclick = trainers_click;
	trainers_item.onmouseover = trainers_mouse_over;
	trainers_item.onmouseout = trainers_mouse_out;
	
	cap_click();
};

function cap_mouse_over(){
	if(cap_index != 1){
		var cap_icon = document.getElementById("cap_icon");
		cap_icon.style.content = "url(../img/cap_2.png)";
		cap_icon.style.width = "70px";
		cap_icon.style.height = "70px";
		cap_icon.style.margin = "15px";
	}
}
function cap_mouse_out(){
	if(cap_index != 1){
		var cap_icon = document.getElementById("cap_icon");
		cap_icon.style.content = "url(../img/cap_1.png)";
		cap_icon.style.width = "50px";
		cap_icon.style.height = "50px";
		cap_icon.style.margin = "25px";
	}
}
function cap_click(){
	cap_index = 1;
	t_shirt_index = 0;
	shorts_index = 0;
	trousers_index = 0;
	trainers_index = 0;
	
	var cap_icon = document.getElementById("cap_icon");
	cap_icon.style.content = "url(../img/cap_2.png)";
	cap_icon.style.width = "100px";
	cap_icon.style.height = "100px";
	cap_icon.style.margin = "0";
	
	var t_shirt_icon = document.getElementById("t_shirt_icon");
	t_shirt_icon.style.content = "url(../img/t_shirt_1.png)";
	t_shirt_icon.style.width = "50px";
	t_shirt_icon.style.height = "50px";
	t_shirt_icon.style.margin = "25px";
	
	var shorts_icon = document.getElementById("shorts_icon");
	shorts_icon.style.content = "url(../img/shorts_1.png)";
	shorts_icon.style.width = "50px";
	shorts_icon.style.height = "50px";
	shorts_icon.style.margin = "25px";
	
	var trousers_icon = document.getElementById("trousers_icon");
	trousers_icon.style.content = "url(../img/trousers_1.png)";
	trousers_icon.style.width = "50px";
	trousers_icon.style.height = "50px";
	trousers_icon.style.margin = "25px";
	
	var trainers_icon = document.getElementById("trainers_icon");
	trainers_icon.style.content = "url(../img/trainers_1.png)";
	trainers_icon.style.width = "50px";
	trainers_icon.style.height = "50px";
	trainers_icon.style.margin = "25px";
	
	var link_1 = document.getElementById("link_1");
	var image_caption_1 = document.getElementById("image_caption_1");
	var discription_caption_1 = document.getElementById("discription_caption_1");
	var example_image_1 = document.getElementById("example_image_1");
	
	var link_2 = document.getElementById("link_2");
	var image_caption_2 = document.getElementById("image_caption_2");
	var discription_caption_2 = document.getElementById("discription_caption_2");
	var example_image_2 = document.getElementById("example_image_2");
	
	var link_3 = document.getElementById("link_3");
	var image_caption_3 = document.getElementById("image_caption_3");
	var discription_caption_3 = document.getElementById("discription_caption_3");
	var example_image_3 = document.getElementById("example_image_3");
	
	var link_4 = document.getElementById("link_4");
	var image_caption_4 = document.getElementById("image_caption_4");
	var discription_caption_4 = document.getElementById("discription_caption_4");
	var example_image_4 = document.getElementById("example_image_4");
	
	var link_5 = document.getElementById("link_5");
	var image_caption_5 = document.getElementById("image_caption_5");
	var discription_caption_5 = document.getElementById("discription_caption_5");
	var example_image_5 = document.getElementById("example_image_5");
	
	var link_6 = document.getElementById("link_6");
	var image_caption_6 = document.getElementById("image_caption_6");
	var discription_caption_6 = document.getElementById("discription_caption_6");
	var example_image_6 = document.getElementById("example_image_6");
	
	var link_7 = document.getElementById("link_7");
	var image_caption_7 = document.getElementById("image_caption_7");
	var discription_caption_7 = document.getElementById("discription_caption_7");
	var example_image_7 = document.getElementById("example_image_7");
	
	var link_8 = document.getElementById("link_8");
	var image_caption_8 = document.getElementById("image_caption_8");
	var discription_caption_8 = document.getElementById("discription_caption_8");
	var example_image_8 = document.getElementById("example_image_8");
	
	var link_9 = document.getElementById("link_9");
	var image_caption_9 = document.getElementById("image_caption_9");
	var discription_caption_9 = document.getElementById("discription_caption_9");
	var example_image_9 = document.getElementById("example_image_9");
	
	link_1.setAttribute("href", "product.html");
	image_caption_1.innerHTML = "150.0$";
	discription_caption_1.innerHTML = "PUMA<br/>woman cap - 1";
	example_image_1.style.content = "url(../img/cap.png)";
	
	link_2.setAttribute("href", "product.html");
	image_caption_2.innerHTML = "150.0$";
	discription_caption_2.innerHTML = "PUMA<br/>woman cap - 2";
	example_image_2.style.content = "url(../img/cap.png)";
	
	link_3.setAttribute("href", "product.html");
	image_caption_3.innerHTML = "150.0$";
	discription_caption_3.innerHTML = "PUMA<br/>woman cap - 3";
	example_image_3.style.content = "url(../img/cap.png)";
	
	link_4.setAttribute("href", "product.html");
	image_caption_4.innerHTML = "150.0$";
	discription_caption_4.innerHTML = "PUMA<br/>woman cap - 4";
	example_image_4.style.content = "url(../img/cap.png)";
	
	link_5.setAttribute("href", "product.html");
	image_caption_5.innerHTML = "150.0$";
	discription_caption_5.innerHTML = "PUMA<br/>woman cap - 5";
	example_image_5.style.content = "url(../img/cap.png)";
	
	link_6.setAttribute("href", "product.html");
	image_caption_6.innerHTML = "150.0$";
	discription_caption_6.innerHTML = "PUMA<br/>woman cap - 6";
	example_image_6.style.content = "url(../img/cap.png)";
	
	link_7.setAttribute("href", "product.html");
	image_caption_7.innerHTML = "150.0$";
	discription_caption_7.innerHTML = "PUMA<br/>woman cap - 7";
	example_image_7.style.content = "url(../img/cap.png)";
	
	link_8.setAttribute("href", "product.html");
	image_caption_8.innerHTML = "150.0$";
	discription_caption_8.innerHTML = "PUMA<br/>woman cap - 8";
	example_image_8.style.content = "url(../img/cap.png)";
	
	link_9.setAttribute("href", "product.html");
	image_caption_9.innerHTML = "150.0$";
	discription_caption_9.innerHTML = "PUMA<br/>woman cap - 9";
	example_image_9.style.content = "url(../img/cap.png)";
	
	link_2.setAttribute("href", "product.html");
	link_3.setAttribute("href", "product.html");
	link_4.setAttribute("href", "product.html");
	link_5.setAttribute("href", "product.html");
	link_6.setAttribute("href", "product.html");
	link_7.setAttribute("href", "product.html");
	link_8.setAttribute("href", "product.html");
	link_9.setAttribute("href", "product.html");
}

function t_shirt_mouse_over(){
	if(t_shirt_index != 1){
		var t_shirt_icon = document.getElementById("t_shirt_icon");
		t_shirt_icon.style.content = "url(../img/t_shirt_2.png)";
		t_shirt_icon.style.width = "70px";
		t_shirt_icon.style.height = "70px";
		t_shirt_icon.style.margin = "15px";
	}
}
function t_shirt_mouse_out(){
	if(t_shirt_index != 1){
		var cap_icon = document.getElementById("t_shirt_icon");
		t_shirt_icon.style.content = "url(../img/t_shirt_1.png)";
		t_shirt_icon.style.width = "50px";
		t_shirt_icon.style.height = "50px";
		t_shirt_icon.style.margin = "25px";
	}
}
function t_shirt_click(){
	cap_index = 0;
	t_shirt_index = 1;
	shorts_index = 0;
	trousers_index = 0;
	trainers_index = 0;

	var cap_icon = document.getElementById("cap_icon");
	cap_icon.style.content = "url(../img/cap_1.png)";
	cap_icon.style.width = "50px";
	cap_icon.style.height = "50px";
	cap_icon.style.margin = "25px";
	
	var t_shirt_icon = document.getElementById("t_shirt_icon");
	t_shirt_icon.style.content = "url(../img/t_shirt_2.png)";
	t_shirt_icon.style.width = "100px";
	t_shirt_icon.style.height = "100px";
	t_shirt_icon.style.margin = "0";
	
	var shorts_icon = document.getElementById("shorts_icon");
	shorts_icon.style.content = "url(../img/shorts_1.png)";
	shorts_icon.style.width = "50px";
	shorts_icon.style.height = "50px";
	shorts_icon.style.margin = "25px";
	
	var trousers_icon = document.getElementById("trousers_icon");
	trousers_icon.style.content = "url(../img/trousers_1.png)";
	trousers_icon.style.width = "50px";
	trousers_icon.style.height = "50px";
	trousers_icon.style.margin = "25px";
	
	var trainers_icon = document.getElementById("trainers_icon");
	trainers_icon.style.content = "url(../img/trainers_1.png)";
	trainers_icon.style.width = "50px";
	trainers_icon.style.height = "50px";
	trainers_icon.style.margin = "25px";
	
	var link_1 = document.getElementById("link_1");
	var image_caption_1 = document.getElementById("image_caption_1");
	var discription_caption_1 = document.getElementById("discription_caption_1");
	var example_image_1 = document.getElementById("example_image_1");
	
	var link_2 = document.getElementById("link_2");
	var image_caption_2 = document.getElementById("image_caption_2");
	var discription_caption_2 = document.getElementById("discription_caption_2");
	var example_image_2 = document.getElementById("example_image_2");
	
	var link_3 = document.getElementById("link_3");
	var image_caption_3 = document.getElementById("image_caption_3");
	var discription_caption_3 = document.getElementById("discription_caption_3");
	var example_image_3 = document.getElementById("example_image_3");
	
	var link_4 = document.getElementById("link_4");
	var image_caption_4 = document.getElementById("image_caption_4");
	var discription_caption_4 = document.getElementById("discription_caption_4");
	var example_image_4 = document.getElementById("example_image_4");
	
	var link_5 = document.getElementById("link_5");
	var image_caption_5 = document.getElementById("image_caption_5");
	var discription_caption_5 = document.getElementById("discription_caption_5");
	var example_image_5 = document.getElementById("example_image_5");
	
	var link_6 = document.getElementById("link_6");
	var image_caption_6 = document.getElementById("image_caption_6");
	var discription_caption_6 = document.getElementById("discription_caption_6");
	var example_image_6 = document.getElementById("example_image_6");
	
	var link_7 = document.getElementById("link_7");
	var image_caption_7 = document.getElementById("image_caption_7");
	var discription_caption_7 = document.getElementById("discription_caption_7");
	var example_image_7 = document.getElementById("example_image_7");
	
	var link_8 = document.getElementById("link_8");
	var image_caption_8 = document.getElementById("image_caption_8");
	var discription_caption_8 = document.getElementById("discription_caption_8");
	var example_image_8 = document.getElementById("example_image_8");
	
	var link_9 = document.getElementById("link_9");
	var image_caption_9 = document.getElementById("image_caption_9");
	var discription_caption_9 = document.getElementById("discription_caption_9");
	var example_image_9 = document.getElementById("example_image_9");
	
	link_1.setAttribute("href", "product.html");
	image_caption_1.innerHTML = "150.0$";
	discription_caption_1.innerHTML = "PUMA<br/>woman t_shirt - 1";
	example_image_1.style.content = "url(../img/t_shirt.png)";
	
	link_2.setAttribute("href", "product.html");
	image_caption_2.innerHTML = "150.0$";
	discription_caption_2.innerHTML = "PUMA<br/>woman t_shirt - 2";
	example_image_2.style.content = "url(../img/t_shirt.png)";
	
	link_3.setAttribute("href", "product.html");
	image_caption_3.innerHTML = "150.0$";
	discription_caption_3.innerHTML = "PUMA<br/>woman t_shirt - 3";
	example_image_3.style.content = "url(../img/t_shirt.png)";
	
	link_4.setAttribute("href", "product.html");
	image_caption_4.innerHTML = "150.0$";
	discription_caption_4.innerHTML = "PUMA<br/>woman t_shirt - 4";
	example_image_4.style.content = "url(../img/t_shirt.png)";
	
	link_5.setAttribute("href", "product.html");
	image_caption_5.innerHTML = "150.0$";
	discription_caption_5.innerHTML = "PUMA<br/>woman t_shirt - 5";
	example_image_5.style.content = "url(../img/t_shirt.png)";
	
	link_6.setAttribute("href", "product.html");
	image_caption_6.innerHTML = "150.0$";
	discription_caption_6.innerHTML = "PUMA<br/>woman t_shirt - 6";
	example_image_6.style.content = "url(../img/t_shirt.png)";
	
	link_7.setAttribute("href", "product.html");
	image_caption_7.innerHTML = "150.0$";
	discription_caption_7.innerHTML = "PUMA<br/>woman t_shirt - 7";
	example_image_7.style.content = "url(../img/t_shirt.png)";
	
	link_8.setAttribute("href", "product.html");
	image_caption_8.innerHTML = "150.0$";
	discription_caption_8.innerHTML = "PUMA<br/>woman t_shirt - 8";
	example_image_8.style.content = "url(../img/t_shirt.png)";
	
	link_9.setAttribute("href", "product.html");
	image_caption_9.innerHTML = "150.0$";
	discription_caption_9.innerHTML = "PUMA<br/>woman t_shirt - 9";
	example_image_9.style.content = "url(../img/t_shirt.png)";
	
	link_1.setAttribute("href", "product.html");
	link_2.setAttribute("href", "product.html");
	link_3.setAttribute("href", "product.html");
	link_4.setAttribute("href", "product.html");
	link_5.setAttribute("href", "product.html");
	link_6.setAttribute("href", "product.html");
	link_7.setAttribute("href", "product.html");
	link_8.setAttribute("href", "product.html");
	link_9.setAttribute("href", "product.html");
}

function shorts_mouse_over(){
	if(shorts_index != 1){
		var shorts_icon = document.getElementById("shorts_icon");
		shorts_icon.style.content = "url(../img/shorts_2.png)";
		shorts_icon.style.width = "70px";
		shorts_icon.style.height = "70px";
		shorts_icon.style.margin = "15px";
	}
}
function shorts_mouse_out(){
	if(shorts_index != 1){
		var shorts_icon = document.getElementById("shorts_icon");
		shorts_icon.style.content = "url(../img/shorts_1.png)";
		shorts_icon.style.width = "50px";
		shorts_icon.style.height = "50px";
		shorts_icon.style.margin = "25px";
	}
}
function shorts_click(){
	cap_index = 0;
	t_shirt_index = 0;
	shorts_index = 1;
	trousers_index = 0;
	trainers_index = 0;
	
	var cap_icon = document.getElementById("cap_icon");
	cap_icon.style.content = "url(../img/cap_1.png)";
	cap_icon.style.width = "50px";
	cap_icon.style.height = "50px";
	cap_icon.style.margin = "25px";
	
	var t_shirt_icon = document.getElementById("t_shirt_icon");
	t_shirt_icon.style.content = "url(../img/t_shirt_1.png)";
	t_shirt_icon.style.width = "50px";
	t_shirt_icon.style.height = "50px";
	t_shirt_icon.style.margin = "25px";
	
	var shorts_icon = document.getElementById("shorts_icon");
	shorts_icon.style.content = "url(../img/shorts_2.png)";
	shorts_icon.style.width = "100px";
	shorts_icon.style.height = "100px";
	shorts_icon.style.margin = "0";
	
	var trousers_icon = document.getElementById("trousers_icon");
	trousers_icon.style.content = "url(../img/trousers_1.png)";
	trousers_icon.style.width = "50px";
	trousers_icon.style.height = "50px";
	trousers_icon.style.margin = "25px";
	
	var trainers_icon = document.getElementById("trainers_icon");
	trainers_icon.style.content = "url(../img/trainers_1.png)";
	trainers_icon.style.width = "50px";
	trainers_icon.style.height = "50px";
	trainers_icon.style.margin = "25px";
	
	var link_1 = document.getElementById("link_1");
	var image_caption_1 = document.getElementById("image_caption_1");
	var discription_caption_1 = document.getElementById("discription_caption_1");
	var example_image_1 = document.getElementById("example_image_1");
	
	var link_2 = document.getElementById("link_2");
	var image_caption_2 = document.getElementById("image_caption_2");
	var discription_caption_2 = document.getElementById("discription_caption_2");
	var example_image_2 = document.getElementById("example_image_2");
	
	var link_3 = document.getElementById("link_3");
	var image_caption_3 = document.getElementById("image_caption_3");
	var discription_caption_3 = document.getElementById("discription_caption_3");
	var example_image_3 = document.getElementById("example_image_3");
	
	var link_4 = document.getElementById("link_4");
	var image_caption_4 = document.getElementById("image_caption_4");
	var discription_caption_4 = document.getElementById("discription_caption_4");
	var example_image_4 = document.getElementById("example_image_4");
	
	var link_5 = document.getElementById("link_5");
	var image_caption_5 = document.getElementById("image_caption_5");
	var discription_caption_5 = document.getElementById("discription_caption_5");
	var example_image_5 = document.getElementById("example_image_5");
	
	var link_6 = document.getElementById("link_6");
	var image_caption_6 = document.getElementById("image_caption_6");
	var discription_caption_6 = document.getElementById("discription_caption_6");
	var example_image_6 = document.getElementById("example_image_6");
	
	var link_7 = document.getElementById("link_7");
	var image_caption_7 = document.getElementById("image_caption_7");
	var discription_caption_7 = document.getElementById("discription_caption_7");
	var example_image_7 = document.getElementById("example_image_7");
	
	var link_8 = document.getElementById("link_8");
	var image_caption_8 = document.getElementById("image_caption_8");
	var discription_caption_8 = document.getElementById("discription_caption_8");
	var example_image_8 = document.getElementById("example_image_8");
	
	var link_9 = document.getElementById("link_9");
	var image_caption_9 = document.getElementById("image_caption_9");
	var discription_caption_9 = document.getElementById("discription_caption_9");
	var example_image_9 = document.getElementById("example_image_9");
	
	link_1.setAttribute("href", "product.html");
	image_caption_1.innerHTML = "150.0$";
	discription_caption_1.innerHTML = "PUMA<br/>woman shorts - 1";
	example_image_1.style.content = "url(../img/shorts.png)";
	
	link_2.setAttribute("href", "product.html");
	image_caption_2.innerHTML = "150.0$";
	discription_caption_2.innerHTML = "PUMA<br/>woman shorts - 2";
	example_image_2.style.content = "url(../img/shorts.png)";
	
	link_3.setAttribute("href", "product.html");
	image_caption_3.innerHTML = "150.0$";
	discription_caption_3.innerHTML = "PUMA<br/>woman shorts - 3";
	example_image_3.style.content = "url(../img/shorts.png)";
	
	link_4.setAttribute("href", "product.html");
	image_caption_4.innerHTML = "150.0$";
	discription_caption_4.innerHTML = "PUMA<br/>woman shorts - 4";
	example_image_4.style.content = "url(../img/shorts.png)";
	
	link_5.setAttribute("href", "product.html");
	image_caption_5.innerHTML = "150.0$";
	discription_caption_5.innerHTML = "PUMA<br/>woman shorts - 5";
	example_image_5.style.content = "url(../img/shorts.png)";
	
	link_6.setAttribute("href", "product.html");
	image_caption_6.innerHTML = "150.0$";
	discription_caption_6.innerHTML = "PUMA<br/>woman shorts - 6";
	example_image_6.style.content = "url(../img/shorts.png)";
	
	link_7.setAttribute("href", "product.html");
	image_caption_7.innerHTML = "150.0$";
	discription_caption_7.innerHTML = "PUMA<br/>woman shorts - 7";
	example_image_7.style.content = "url(../img/shorts.png)";
	
	link_8.setAttribute("href", "product.html");
	image_caption_8.innerHTML = "150.0$";
	discription_caption_8.innerHTML = "PUMA<br/>woman shorts - 8";
	example_image_8.style.content = "url(../img/shorts.png)";
	
	link_9.setAttribute("href", "product.html");
	image_caption_9.innerHTML = "150.0$";
	discription_caption_9.innerHTML = "PUMA<br/>woman shorts - 9";
	example_image_9.style.content = "url(../img/shorts.png)";
	
	link_1.setAttribute("href", "product.html");
	link_2.setAttribute("href", "product.html");
	link_3.setAttribute("href", "product.html");
	link_4.setAttribute("href", "product.html");
	link_5.setAttribute("href", "product.html");
	link_6.setAttribute("href", "product.html");
	link_7.setAttribute("href", "product.html");
	link_8.setAttribute("href", "product.html");
	link_9.setAttribute("href", "product.html");
}

function trousers_mouse_over(){
	if(trousers_index != 1){
		var trousers_icon = document.getElementById("trousers_icon");
		trousers_icon.style.content = "url(../img/trousers_2.png)";
		trousers_icon.style.width = "70px";
		trousers_icon.style.height = "70px";
		trousers_icon.style.margin = "15px";
	}
}
function trousers_mouse_out(){
	if(trousers_index != 1){
		var trousers_icon = document.getElementById("trousers_icon");
		trousers_icon.style.content = "url(../img/trousers_1.png)";
		trousers_icon.style.width = "50px";
		trousers_icon.style.height = "50px";
		trousers_icon.style.margin = "25px";
	}
}
function trousers_click(){
	cap_index = 0;
	t_shirt_index = 0;
	shorts_index = 0;
	trousers_index = 1;
	trainers_index = 0;
	
	var cap_icon = document.getElementById("cap_icon");
	cap_icon.style.content = "url(../img/cap_1.png)";
	cap_icon.style.width = "50px";
	cap_icon.style.height = "50px";
	cap_icon.style.margin = "25px";
	
	var t_shirt_icon = document.getElementById("t_shirt_icon");
	t_shirt_icon.style.content = "url(../img/t_shirt_1.png)";
	t_shirt_icon.style.width = "50px";
	t_shirt_icon.style.height = "50px";
	t_shirt_icon.style.margin = "25px";
	
	var shorts_icon = document.getElementById("shorts_icon");
	shorts_icon.style.content = "url(../img/shorts_1.png)";
	shorts_icon.style.width = "50px";
	shorts_icon.style.height = "50px";
	shorts_icon.style.margin = "25px";
	
	var trousers_icon = document.getElementById("trousers_icon");
	trousers_icon.style.content = "url(../img/trousers_2.png)";
	trousers_icon.style.width = "100px";
	trousers_icon.style.height = "100px";
	trousers_icon.style.margin = "0";
	
	var trainers_icon = document.getElementById("trainers_icon");
	trainers_icon.style.content = "url(../img/trainers_1.png)";
	trainers_icon.style.width = "50px";
	trainers_icon.style.height = "50px";
	trainers_icon.style.margin = "25px";
	
	var link_1 = document.getElementById("link_1");
	var image_caption_1 = document.getElementById("image_caption_1");
	var discription_caption_1 = document.getElementById("discription_caption_1");
	var example_image_1 = document.getElementById("example_image_1");
	
	var link_2 = document.getElementById("link_2");
	var image_caption_2 = document.getElementById("image_caption_2");
	var discription_caption_2 = document.getElementById("discription_caption_2");
	var example_image_2 = document.getElementById("example_image_2");
	
	var link_3 = document.getElementById("link_3");
	var image_caption_3 = document.getElementById("image_caption_3");
	var discription_caption_3 = document.getElementById("discription_caption_3");
	var example_image_3 = document.getElementById("example_image_3");
	
	var link_4 = document.getElementById("link_4");
	var image_caption_4 = document.getElementById("image_caption_4");
	var discription_caption_4 = document.getElementById("discription_caption_4");
	var example_image_4 = document.getElementById("example_image_4");
	
	var link_5 = document.getElementById("link_5");
	var image_caption_5 = document.getElementById("image_caption_5");
	var discription_caption_5 = document.getElementById("discription_caption_5");
	var example_image_5 = document.getElementById("example_image_5");
	
	var link_6 = document.getElementById("link_6");
	var image_caption_6 = document.getElementById("image_caption_6");
	var discription_caption_6 = document.getElementById("discription_caption_6");
	var example_image_6 = document.getElementById("example_image_6");
	
	var link_7 = document.getElementById("link_7");
	var image_caption_7 = document.getElementById("image_caption_7");
	var discription_caption_7 = document.getElementById("discription_caption_7");
	var example_image_7 = document.getElementById("example_image_7");
	
	var link_8 = document.getElementById("link_8");
	var image_caption_8 = document.getElementById("image_caption_8");
	var discription_caption_8 = document.getElementById("discription_caption_8");
	var example_image_8 = document.getElementById("example_image_8");
	
	var link_9 = document.getElementById("link_9");
	var image_caption_9 = document.getElementById("image_caption_9");
	var discription_caption_9 = document.getElementById("discription_caption_9");
	var example_image_9 = document.getElementById("example_image_9");
	
	link_1.setAttribute("href", "product.html");
	image_caption_1.innerHTML = "150.0$";
	discription_caption_1.innerHTML = "PUMA<br/>woman trousers - 1";
	example_image_1.style.content = "url(../img/trousers.png)";
	
	link_2.setAttribute("href", "product.html");
	image_caption_2.innerHTML = "150.0$";
	discription_caption_2.innerHTML = "PUMA<br/>woman trousers - 2";
	example_image_2.style.content = "url(../img/trousers.png)";
	
	link_3.setAttribute("href", "product.html");
	image_caption_3.innerHTML = "150.0$";
	discription_caption_3.innerHTML = "PUMA<br/>woman trousers - 3";
	example_image_3.style.content = "url(../img/trousers.png)";
	
	link_4.setAttribute("href", "product.html");
	image_caption_4.innerHTML = "150.0$";
	discription_caption_4.innerHTML = "PUMA<br/>woman trousers - 4";
	example_image_4.style.content = "url(../img/trousers.png)";
	
	link_5.setAttribute("href", "product.html");
	image_caption_5.innerHTML = "150.0$";
	discription_caption_5.innerHTML = "PUMA<br/>woman trousers - 5";
	example_image_5.style.content = "url(../img/trousers.png)";
	
	link_6.setAttribute("href", "product.html");
	image_caption_6.innerHTML = "150.0$";
	discription_caption_6.innerHTML = "PUMA<br/>woman trousers - 6";
	example_image_6.style.content = "url(../img/trousers.png)";
	
	link_7.setAttribute("href", "product.html");
	image_caption_7.innerHTML = "150.0$";
	discription_caption_7.innerHTML = "PUMA<br/>woman trousers - 7";
	example_image_7.style.content = "url(../img/trousers.png)";
	
	link_8.setAttribute("href", "product.html");
	image_caption_8.innerHTML = "150.0$";
	discription_caption_8.innerHTML = "PUMA<br/>woman trousers - 8";
	example_image_8.style.content = "url(../img/trousers.png)";
	
	link_9.setAttribute("href", "product.html");
	image_caption_9.innerHTML = "150.0$";
	discription_caption_9.innerHTML = "PUMA<br/>woman trousers - 9";
	example_image_9.style.content = "url(../img/trousers.png)";
	
	link_1.setAttribute("href", "product.html");
	link_2.setAttribute("href", "product.html");
	link_3.setAttribute("href", "product.html");
	link_4.setAttribute("href", "product.html");
	link_5.setAttribute("href", "product.html");
	link_6.setAttribute("href", "product.html");
	link_7.setAttribute("href", "product.html");
	link_8.setAttribute("href", "product.html");
	link_9.setAttribute("href", "product.html");
}

function trainers_mouse_over(){
	if(trainers_index != 1){
		var trainers_icon = document.getElementById("trainers_icon");
		trainers_icon.style.content = "url(../img/trainers_2.png)";
		trainers_icon.style.width = "70px";
		trainers_icon.style.height = "70px";
		trainers_icon.style.margin = "15px";
	}
}
function trainers_mouse_out(){
	if(trainers_index != 1){
		var trainers_icon = document.getElementById("trainers_icon");
		trainers_icon.style.content = "url(../img/trainers_1.png)";
		trainers_icon.style.width = "50px";
		trainers_icon.style.height = "50px";
		trainers_icon.style.margin = "25px";
	}
}
function trainers_click(){
	cap_index = 0;
	t_shirt_index = 0;
	shorts_index = 0;
	trousers_index = 0;
	trainers_index = 1;
	
	var cap_icon = document.getElementById("cap_icon");
	cap_icon.style.content = "url(../img/cap_1.png)";
	cap_icon.style.width = "50px";
	cap_icon.style.height = "50px";
	cap_icon.style.margin = "25px";
	
	var t_shirt_icon = document.getElementById("t_shirt_icon");
	t_shirt_icon.style.content = "url(../img/t_shirt_1.png)";
	t_shirt_icon.style.width = "50px";
	t_shirt_icon.style.height = "50px";
	t_shirt_icon.style.margin = "25px";
	
	var shorts_icon = document.getElementById("shorts_icon");
	shorts_icon.style.content = "url(../img/shorts_1.png)";
	shorts_icon.style.width = "50px";
	shorts_icon.style.height = "50px";
	shorts_icon.style.margin = "25px";
	
	var trousers_icon = document.getElementById("trousers_icon");
	trousers_icon.style.content = "url(../img/trousers_1.png)";
	trousers_icon.style.width = "50px";
	trousers_icon.style.height = "50px";
	trousers_icon.style.margin = "25px";
	
	var trainers_icon = document.getElementById("trainers_icon");
	trainers_icon.style.content = "url(../img/trainers_2.png)";
	trainers_icon.style.width = "100px";
	trainers_icon.style.height = "100px";
	trainers_icon.style.margin = "0";
	
	var link_1 = document.getElementById("link_1");
	var image_caption_1 = document.getElementById("image_caption_1");
	var discription_caption_1 = document.getElementById("discription_caption_1");
	var example_image_1 = document.getElementById("example_image_1");
	
	var link_2 = document.getElementById("link_2");
	var image_caption_2 = document.getElementById("image_caption_2");
	var discription_caption_2 = document.getElementById("discription_caption_2");
	var example_image_2 = document.getElementById("example_image_2");
	
	var link_3 = document.getElementById("link_3");
	var image_caption_3 = document.getElementById("image_caption_3");
	var discription_caption_3 = document.getElementById("discription_caption_3");
	var example_image_3 = document.getElementById("example_image_3");
	
	var link_4 = document.getElementById("link_4");
	var image_caption_4 = document.getElementById("image_caption_4");
	var discription_caption_4 = document.getElementById("discription_caption_4");
	var example_image_4 = document.getElementById("example_image_4");
	
	var link_5 = document.getElementById("link_5");
	var image_caption_5 = document.getElementById("image_caption_5");
	var discription_caption_5 = document.getElementById("discription_caption_5");
	var example_image_5 = document.getElementById("example_image_5");
	
	var link_6 = document.getElementById("link_6");
	var image_caption_6 = document.getElementById("image_caption_6");
	var discription_caption_6 = document.getElementById("discription_caption_6");
	var example_image_6 = document.getElementById("example_image_6");
	
	var link_7 = document.getElementById("link_7");
	var image_caption_7 = document.getElementById("image_caption_7");
	var discription_caption_7 = document.getElementById("discription_caption_7");
	var example_image_7 = document.getElementById("example_image_7");
	
	var link_8 = document.getElementById("link_8");
	var image_caption_8 = document.getElementById("image_caption_8");
	var discription_caption_8 = document.getElementById("discription_caption_8");
	var example_image_8 = document.getElementById("example_image_8");
	
	var link_9 = document.getElementById("link_9");
	var image_caption_9 = document.getElementById("image_caption_9");
	var discription_caption_9 = document.getElementById("discription_caption_9");
	var example_image_9 = document.getElementById("example_image_9");
	
	link_1.setAttribute("href", "product.html");
	image_caption_1.innerHTML = "150.0$";
	discription_caption_1.innerHTML = "PUMA<br/>woman trainers - 1";
	example_image_1.style.content = "url(../img/trainers.png)";
	
	link_2.setAttribute("href", "product.html");
	image_caption_2.innerHTML = "150.0$";
	discription_caption_2.innerHTML = "PUMA<br/>woman trainers - 2";
	example_image_2.style.content = "url(../img/trainers.png)";
	
	link_3.setAttribute("href", "product.html");
	image_caption_3.innerHTML = "150.0$";
	discription_caption_3.innerHTML = "PUMA<br/>woman trainers - 3";
	example_image_3.style.content = "url(../img/trainers.png)";
	
	link_4.setAttribute("href", "product.html");
	image_caption_4.innerHTML = "150.0$";
	discription_caption_4.innerHTML = "PUMA<br/>woman trainers - 4";
	example_image_4.style.content = "url(../img/trainers.png)";
	
	link_5.setAttribute("href", "product.html");
	image_caption_5.innerHTML = "150.0$";
	discription_caption_5.innerHTML = "PUMA<br/>woman trainers - 5";
	example_image_5.style.content = "url(../img/trainers.png)";
	
	link_6.setAttribute("href", "product.html");
	image_caption_6.innerHTML = "150.0$";
	discription_caption_6.innerHTML = "PUMA<br/>woman trainers - 6";
	example_image_6.style.content = "url(../img/trainers.png)";
	
	link_7.setAttribute("href", "product.html");
	image_caption_7.innerHTML = "150.0$";
	discription_caption_7.innerHTML = "PUMA<br/>woman trainers - 7";
	example_image_7.style.content = "url(../img/trainers.png)";
	
	link_8.setAttribute("href", "product.html");
	image_caption_8.innerHTML = "150.0$";
	discription_caption_8.innerHTML = "PUMA<br/>woman trainers - 8";
	example_image_8.style.content = "url(../img/trainers.png)";
	
	link_9.setAttribute("href", "product.html");
	image_caption_9.innerHTML = "150.0$";
	discription_caption_9.innerHTML = "PUMA<br/>woman trainers - 9";
	example_image_9.style.content = "url(../img/trainers.png)";
	
	link_1.setAttribute("href", "product.html");
	link_2.setAttribute("href", "product.html");
	link_3.setAttribute("href", "product.html");
	link_4.setAttribute("href", "product.html");
	link_5.setAttribute("href", "product.html");
	link_6.setAttribute("href", "product.html");
	link_7.setAttribute("href", "product.html");
	link_8.setAttribute("href", "product.html");
	link_9.setAttribute("href", "product.html");
}