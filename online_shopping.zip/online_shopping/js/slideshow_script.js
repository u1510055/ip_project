var array = new Array("url(img/car1.jpg)", "url(img/car2.jpg)",
					"url(img/car3.jpg)", "url(img/car4.jpg)", "url(img/car5.jpg)");
					
var i = 0;

function slideshow_func() {
	var slideshow = document.getElementById("slideshow");
	slideshow.style.background = array[i];
	slideshow.style.backgroundPosition = "center center";
	slideshow.style.backgroundRepeat = "no-repeat";
	i++;
	
	if(i == 5){
		i = 0;
	}
}

function prev_click() {
	if(i <= 0){
		i = 4;
	}
	else {
		i--;
	}
	var slideshow = document.getElementById("slideshow");
	slideshow.style.background = array[i];
	slideshow.style.backgroundPosition = "center center";
	slideshow.style.backgroundRepeat = "no-repeat";
}

function next_click() {
	if(i >= 4){
		i = 0;
	}
	else {
		i++;
	}
	var slideshow = document.getElementById("slideshow");
	slideshow.style.background = array[i];
	slideshow.style.backgroundPosition = "center center";
	slideshow.style.backgroundRepeat = "no-repeat";
}

var interval = setInterval("slideshow_func()", 3000);