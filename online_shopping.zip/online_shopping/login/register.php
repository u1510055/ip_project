<?php 
if ($_SERVER["REQUEST_METHOD"]=="POST") {
//$id=mysql_real_escape_string($_POST['id']); 
$id=0; 
$username = mysql_real_escape_string($_POST['username']);
$password = mysql_real_escape_string($_POST['password']);
$name=mysql_real_escape_string($_POST['name']);
$email=mysql_real_escape_string($_POST['email']);
$bool=true;

mysql_connect("localhost","root")or die(mysql_error());
mysql_select_db("first_db")or die("Cannot connect to database");
$query=mysql_query("Select * from users");
while ($row=mysql_fetch_array($query)) {
  # code...
  $table_users=$row['username'];
  if($username==$table_users){

    $bool=false;

    Print '<script>alert("username has been taken");</script>';
    Print '<script>window.location.assign("register.php")</script>';
  }
}

if ($bool) {
  //id++;

  mysql_query("INSERT INTO users(username,password,name,email) VALUES('$username','$password','$name','$email')");
  Print'<script>alert("Sucessfully registered");</script>';
  Print'<script>window.location.assign("register.php");</script>)';

  
}


}

?>

<!DOCTYPE html>
<html>
<head>
	<title>
		register_page
	</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
<div class="col-md-3"></div>
<div class="col-md-6">
 <h2>Registration Form</h2>
  <form action="register.php" method="POST">
    <div class="form-group">
      <label for="name">Username:</label>
      <input type="username" class="form-control" name="username" required="required" id="name" placeholder="Enter username">
      </div>
      
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" name="password" required="required" id="pwd" placeholder="Enter password">
    </div>
   <div class="form-group">
      <label for="name">Name:</label>
      <input type="name" class="form-control" id="username" name="name" required="required" placeholder="Your name">
      </div>
    <div class="form-group">
      <label for="pwd">Email:</label>
      <input type="email" class="form-control" id="email" name="email" required="required" placeholder="Your email">
    </div>
    

    <input type="submit" value="Register">
   </form>
  </div>
  <div class="col-md-3"></div>
</div>

</body>
</html>