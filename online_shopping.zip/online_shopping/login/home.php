<!DOCTYPE html>
<html>
<head>
	<title>homePage</title>
</head>
<?php
session_start();
if ($_SESSION['user']) {
	
}
else {
	header("location:index.php");
}
$user=$_SESSION['user'];
?>
<body>
<h2>
	home page
</h2>
<p>
	Hello <?php Print "$user" ?>

</p>
<a href="logout.php">Click here to log out</a><br><br>
<form>
	add something to the list <input type="text" name="details"><br>
	public post? <input type="checkbox" name="public[]" value="yes"><br><br>

</form>
<h2 align="center">my list</h2>
<table border="1px" width="100%">
	<tr>
		<th>id</th>
		<th>details</th>
		<th>edit</th>
		<th>delete</th>
	</tr>
</table>
</body>
</html>