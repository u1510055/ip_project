<?php 


?>

<!DOCTYPE html>
<html>
<head>
	<title>
		login_page
	</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
<div class="col-md-3"></div>
<div class="col-md-6">
 <h2>Login page</h2>
  <form action="checklogin.php" method="POST">
    <div class="form-group">
      <label for="name">Username:</label>
      <input type="username" class="form-control" id="username" name="username" required="required" placeholder="Your name">
      </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="password" name="password" required="required" placeholder="Your password">
      </div>
   <!--  <div class="form-group">
      <label for="name">Name:</label>
      <input type="name" class="form-control" id="username" name="name" required="required" placeholder="Your name">
      </div>
    <div class="form-group">
      <label for="pwd">Email:</label>
      <input type="email" class="form-control" id="email" name="email" required="required" placeholder="Your email">
    </div>
    --> <!--   <div class="checkbox">
      <label><input type="checkbox"> Remember me</label>
    </div>
 -->
     <input type="submit" value="Login"> 
  </form>
  </div>
  <div class="col-md-3"></div>
</div>

</body>
</html>