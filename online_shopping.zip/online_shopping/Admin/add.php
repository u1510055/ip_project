<?php
	$title = $_POST["title"];
	$description=$_POST["description"];
	$cost = $_POST["cost"];
	$type = $_POST["type"];
	$file = $_POST["picture"];
	
	include "db.php";
$sql = "INSERT INTO products (title, description, cost, type, link)
VALUES ('{$title}', '{$description}', '{$cost}', '{$type}', '{$file}')";

$result = mysql_query($sql) or die(mysql_error()) ;

if ($result) {
    echo "New record created successfully";
}
    	header("Location: admin.php");
?>