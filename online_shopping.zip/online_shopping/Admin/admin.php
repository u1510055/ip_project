<?php


?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
</head>
<body>
<h3 align="center">Admin page of the Sports Store</h3><hr><br>
<div class="container">
	<div class="row">
		<div class="col-md-12">
		<form method="post" action="upload.php"  enctype="multipart/form-data" >
			<label for="type">Type
			<select class="form-control" id="sel1">
			<option>cap</option>
			<option>t-shirt</option>	
			<option>shorts</option>	
			<option>t-shirt</option>	
			<option>trainers</option>	
			</select> 
			</label>
			<div class="radio">
			<label for="gender" class="radio-inline"><input type="radio" name="optradio">men</label>
			<label for="gender" class="radio-inline"><input type="radio" name="optradio">women</label>
			<label for="gender" class="radio-inline"><input type="radio" name="optradio">kids</label>
			</div>
			<div class="price">
			<label for="price">price</label><input type="text" name="">
			</div>
			<div class="size">
		<label for="sel2">Size of the Product:</label>
      <select multiple class="form-control" id="sel2">
        <option>38</option>
        <option>39</option>
        <option>40</option>
        <option>41</option>
        <option>42</option>
      </select></label>
			</div>
			<div class="brand">
				<label>Brands<select class="form-control" id="sel2">
				<option>Adidas</option>
				<option>Boss</option>
				<option>D&G</option>
				<option>Nike</option>
				<option>Puma</option>	
				</select>
				</label>
			</div>
			<div class="info">
			<label for="info">Product Info</label><textarea class="info" name="product_info"></textarea>
			</div>
			<div class="pic">
				<label for="picture"><input type="file" name="file_upload" id="file_upload" value="upload"></label>
			</div>
			<input type="submit" name="submit" value="submit">
		</form>

		</div>
	</div>
</div>

</body>
</html>