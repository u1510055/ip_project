<?php


?>

<!DOCTYPE html>
<html>
<head>
	<title>GOOD JOB</title>
	<script src="./jquery/jquery-3.0.0.min.js" type="text/javascript"></script>
</head>
<body>
<script type="text/javascript">
	var p={
		"first_name":"Alex",
		"last_name":"Jason",
		"age":"46",
		"address":{
			"streetAdress":"67 WestStr 23",
			"City":"Tashkent"
		},
		"powers":[1,2,3,4,5]

	}
// alert(p.age);
	$.ajax({
		dataType:"json",
		url:url,
		data:data,
		success:success
	});
	$.getJSON("ajax/test.json",function(data){
		var items=[];
		$.each(data,function(key,val){
			items.push("<li id='"+key+"'>"+val+"</li>");
		});
		$("<ul/>",{
			"class":"my-new-list",
			html:items.join("")
		}).appendTo("body");
	});



</script>



</body>
</html>