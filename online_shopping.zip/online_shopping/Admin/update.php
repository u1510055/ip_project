<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
</head>
<body>
<?php
		$dbhost = "localhost";
		$dbuser = "root";
		$dbpass = "";
	try {
	    $conn = new PDO("mysql:host=localhost;dbname=sport_store", $dbuser, $dbpass);
	    // set the PDO error mode to exception
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    }
	catch(PDOException $e)
	    {
	    echo "Connection failed: " . $e->getMessage();
	    }


	     $sql = "SELECT name FROM clothes";
	    // printf("<form method='post' action='update.php'>");
	     $conn->query($sql);
       	 foreach ($conn->query($sql) as $row) {?>
       	 		<a href="update.php?name=<?php $row['name']?>"><?php echo $row["name"]?></a>
      		<?php // printf("<br><a href='update.php?name=%s'>",$row['name']);
   		 }
   		// printf("</form>");



?>


</body>
</html>