<?php
		$dbhost = "localhost";
		$dbuser = "root";
		$dbpass = "";
	try {
	    $conn = new PDO("mysql:host=localhost;dbname=sport_store", $dbuser, $dbpass);
	    // set the PDO error mode to exception
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    }
	catch(PDOException $e)
	    {
	    echo "Connection failed: " . $e->getMessage();
	    }

		foreach ($_POST as $key => $value) {
			$sql = "DELETE from clothes where id='{$key}'";
			$conn->query($sql);
		}
	//header("Location: admin.php");

?>