<?php

	$type  = $_POST["type"];
	$name  = $_POST["name"];
	$for  = $_POST["for"];
	$quantity  = $_POST["quantity"];
	$price  = $_POST["price"];
	$size  = $_POST["size"];
	$brend  = $_POST["brend"];
	$product_info  = $_POST["product_info"];
	$material  = $_POST["material"];
	
	if(isset($_POST['btn'])){
		
		$dbhost = "localhost";
		$dbuser = "root";
		$dbpass = "";
	try {
	    $conn = new PDO("mysql:host=localhost;dbname=sport_store", $dbuser, $dbpass);
	    // set the PDO error mode to exception
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    }
	catch(PDOException $e)
	    {
	    echo "Connection failed: " . $e->getMessage();
	    }

		$target_dir = "uploads/";
		$target_file = $target_dir . basename($_FILES["file_upload"]["name"]);

		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// Check if image file is a actual image or fake image
		if(isset($_POST["btn"])) {
		    $check = getimagesize($_FILES["file_upload"]["tmp_name"]);
		    if($check !== false) {
		        move_uploaded_file($_FILES["file_upload"]["tmp_name"], "uploads/" . $_FILES["file_upload"]["name"]);
		        $uploadOk = 1;
		    } else {
		        echo "File is not an image.";
		        $uploadOk = 0;
		    }
		}


		$sql = "INSERT INTO clothes(type, `for`, name, quantity, price, size, brend, product_info, material, picture) VALUES ('{$type}','{$for}','{$name}','{$quantity}','{$price}',
		'{$size}','{$brend}','{$product_info}','{$material}','{$target_file}')";
							
		$stmt = $conn->prepare($sql);
		$stmt->execute();

}



?>