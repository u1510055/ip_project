<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
  try {
      $conn = new PDO("mysql:host=localhost;dbname=sport_store", $dbuser, $dbpass);
      // set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      }
  catch(PDOException $e)
      {
      echo "Connection failed: " . $e->getMessage();  
      }

 $res =  $conn->query("SELECT * FROM clothes");
 $row = $res->fetch(PDO::FETCH_ASSOC);
 do{
  	echo "<form method='post' action=delete.php>";
        printf("<div class='form-group'>
                        <div class='col-md-6'>
                            <div class='checkbox'>
                                <label>
                                    <input type='checkbox' name='%s' />%s\t\t%s
                                    <img src='%s'>
                                </label>
                        </div>
                  </div>
<div class='form-group'>",$row["id"],$row["name"],$row["type"],$row["picture"]);
} while ($row = $res->fetch(PDO::FETCH_ASSOC)); 
        echo "<div class='form-group'><style>padding:20px; </style>
  <label class='col-md-6 control-label'></label>
  <div class='col-md-6'>
    <button type='submit' class='btn btn-warning' >Delete </button>
  </div>
</div>
 </form>";
?>
